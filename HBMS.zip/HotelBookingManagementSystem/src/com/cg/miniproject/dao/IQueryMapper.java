package com.cg.miniproject.dao;

public interface IQueryMapper {
	String QUERY1 = "INSERT INTO Users VALUES(userId_sequence.NEXTVAL,?,?,?,?,?,?,?)";
	String QUERY2 = "SELECT USER_NAME,PASSWORD FROM Users WHERE USER_NAME=? AND PASSWORD=? AND Role=?";
	String QUERY3 = "INSERT INTO hotel(hotel_id,hotel_name,address,description,city,avg_rate_per_night) VALUES (?,?,?,?,?,?)";
	String QUERY4 = "DELETE FROM hotel WHERE hotel_id=?";
	String QUERY5 = "INSERT INTO roomdetails VALUES (?,?,?,?,?,?)";
	String QUERY6 = "DELETE FROM roomdetails WHERE room_id=?";
	String QUERY7 = "SELECT b.* FROM bookingdetails b join roomdetails r on b.room_id=r.room_id join hotel h ON h.hotel_id=r.hotel_id WHERE h.hotel_id=?";
	String QUERY8 = "SELECT * FROM bookingdetails WHERE booked_from<=to_date(?,'YYYY-MM-DD') and booked_to>=to_date(?,'YYYY-MM-DD')";
	String QUERY9 = "SELECT city,hotel_name,hotel_id FROM Hotel";
	String QUERY10 = "SELECT hotel_id,room_id,room_no,room_type,per_night_rate,availability FROM RoomDetails WHERE hotel_id = ? and availability='A'";
	String QUERY11 = "SELECT per_night_rate FROM RoomDetails WHERE room_id=?";
	String QUERY12 = "INSERT INTO BookingDetails VALUES(seq_booking.nextval,?,?,?,?,?,?,?)";
	String QUERY13 = "UPDATE roomdetails SET availability='NA' WHERE room_id=?";
	String QUERY14 = "SELECT user_id FROM users WHERE USER_NAME=? AND PASSWORD=? AND Role=? ";
	String QUERY15 = "SELECT sum(no_of_adults),sum(no_of_children) FROM bookingdetails b join roomdetails r ON b.room_id=r.room_id join hotel h ON h.hotel_id=r.hotel_id WHERE h.hotel_id=?";
	String QUERY16 = "SELECT user_name FROM users WHERE user_name = ?";
	String QUERY17 = "SELECT user_id FROM bookingdetails WHERE user_id=?";
	String QUERY18 = "UPDATE hotel SET avg_rate_per_night=?,rating=? WHERE hotel_id=?";
	String QUERY19 = "UPDATE roomdetails SET per_night_rate=? WHERE hotel_id=? AND room_id=?";
	String QUERY20 = "SELECT hotel_id FROM Hotel WHERE hotel_id=?";
}
